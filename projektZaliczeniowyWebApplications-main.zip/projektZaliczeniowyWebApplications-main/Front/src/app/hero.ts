export interface Hero {
  id: number;
  name: string;
  author: string;
  isbn: string;
}
