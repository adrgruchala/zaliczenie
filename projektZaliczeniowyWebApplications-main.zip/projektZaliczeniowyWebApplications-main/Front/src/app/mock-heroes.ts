import {Hero} from './hero';

export const HEROES: Hero[] = [
  {id: 11, name: 'Dr Nice', author: 'author1', isbn: '123'},
  {id: 12, name: 'Narco', author: 'author1', isbn: '12'},
  {id: 13, name: 'Bombasto', author: 'author1', isbn: '324'},
  {id: 14, name: 'Celeritas', author: 'author1', isbn: '213'},
  {id: 15, name: 'Magneta', author: 'author1', isbn: '213'},
  {id: 16, name: 'RubberMan', author: 'author1', isbn: '3214'},
  {id: 17, name: 'Dynama', author: 'author1', isbn: '421'},
  {id: 18, name: 'Dr IQ', author: 'author1', isbn: '3412'},
  {id: 19, name: 'Magma', author: 'author1', isbn: '421421'},
  {id: 20, name: 'Tornado', author: 'author1', isbn: '4214122'}
];
